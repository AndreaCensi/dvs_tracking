/************************************************************************
*
*  Module:       stdafx.h
*  Description:
*     wrapper for the library global include file
*
*  Author(s):   
*    Udo Eberhardt
*                
*  Companies:
*    Thesycon GmbH, Germany      http://www.thesycon.de
*                
************************************************************************/

#ifndef __stdafx_h__
#define __stdafx_h__


#endif  // __stdafx_h__

/*************************** EOF **************************************/
