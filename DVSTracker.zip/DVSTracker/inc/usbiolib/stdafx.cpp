/************************************************************************
 *
 *  Module:       stdafx.cpp
 *  Description:
 *     library global functions, variables, etc.
 *
 *  Author(s):   
 *    Udo Eberhardt
 *                
 *  Companies:
 *    Thesycon GmbH, Germany      http://www.thesycon.de
 *                
 ************************************************************************/

#include "stdafx.h"


// to suppress linker warning: 'no public symbols found'
// dummy variable
int g_dummy_dummy;



/*************************** EOF **************************************/
